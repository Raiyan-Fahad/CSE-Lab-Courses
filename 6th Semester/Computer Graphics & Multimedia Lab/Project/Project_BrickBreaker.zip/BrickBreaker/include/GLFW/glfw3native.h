/* Native GLFW platform access is not used by this project. */
#ifndef BRICKBREAKER_GLFW3NATIVE_H
#define BRICKBREAKER_GLFW3NATIVE_H
#include <GLFW/glfw3.h>
#endif
