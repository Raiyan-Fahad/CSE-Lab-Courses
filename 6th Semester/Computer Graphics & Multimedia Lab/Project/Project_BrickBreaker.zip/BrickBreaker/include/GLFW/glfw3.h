/*
 * Minimal GLFW 3 declarations for this Brick Breaker project.
 * Based on the GLFW 3 public API. The GLFW runtime remains in lib/glfw3.dll.
 * This file only declares the GLFW symbols used by src/main.cpp.
 */
#ifndef BRICKBREAKER_GLFW3_H
#define BRICKBREAKER_GLFW3_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct GLFWwindow GLFWwindow;
typedef struct GLFWmonitor GLFWmonitor;
typedef void (*GLFWglproc)(void);

#define GLFW_PRESS                    1
#define GLFW_KEY_ESCAPE               256
#define GLFW_KEY_RIGHT                262
#define GLFW_KEY_LEFT                 263
#define GLFW_KEY_R                    82
#define GLFW_CONTEXT_VERSION_MAJOR    0x00022002
#define GLFW_CONTEXT_VERSION_MINOR    0x00022003
#define GLFW_OPENGL_PROFILE           0x00022008
#define GLFW_OPENGL_CORE_PROFILE      0x00032001

int glfwInit(void);
void glfwTerminate(void);
void glfwWindowHint(int hint, int value);
GLFWwindow* glfwCreateWindow(int width, int height, const char* title,
                             GLFWmonitor* monitor, GLFWwindow* share);
void glfwMakeContextCurrent(GLFWwindow* window);
void glfwSwapInterval(int interval);
GLFWglproc glfwGetProcAddress(const char* procname);
int glfwWindowShouldClose(GLFWwindow* window);
void glfwSetWindowShouldClose(GLFWwindow* window, int value);
int glfwGetKey(GLFWwindow* window, int key);
void glfwSetWindowTitle(GLFWwindow* window, const char* title);
double glfwGetTime(void);
void glfwSwapBuffers(GLFWwindow* window);
void glfwPollEvents(void);

#ifdef __cplusplus
}
#endif
#endif /* BRICKBREAKER_GLFW3_H */
