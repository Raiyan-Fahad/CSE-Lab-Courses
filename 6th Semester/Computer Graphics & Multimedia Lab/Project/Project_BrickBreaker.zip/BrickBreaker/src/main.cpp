#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <sstream>

const int WIDTH = 900;
const int HEIGHT = 700;

const char* vertexShaderSource = R"(
#version 330 core
layout (location = 0) in vec2 aPos;

void main()
{
    gl_Position = vec4(aPos, 0.0, 1.0);
}
)";

const char* fragmentShaderSource = R"(
#version 330 core
out vec4 FragColor;
uniform vec4 objectColor;

void main()
{
    FragColor = objectColor;
}
)";

struct Brick
{
    float x, y, width, height;
    bool active;
    float r, g, b;
};

float paddleX = 0.0f;
float paddleWidth = 0.25f;
float paddleHeight = 0.035f;

float ballX = 0.0f;
float ballY = -0.65f;
float ballRadius = 0.025f;
float ballSpeedX = 0.45f;
float ballSpeedY = 0.55f;

int score = 0;
int lives = 3;
bool gameOver = false;
bool won = false;

std::vector<Brick> bricks;

GLuint shaderProgram;
GLuint VAO, VBO;

float clampValue(float value, float low, float high)
{
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

GLuint createShaderProgram()
{
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, nullptr);
    glCompileShader(vertexShader);

    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, nullptr);
    glCompileShader(fragmentShader);

    GLint success;
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        char info[512];
        glGetShaderInfoLog(vertexShader, 512, nullptr, info);
        std::cerr << "Vertex shader error: " << info << '\n';
    }

    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        char info[512];
        glGetShaderInfoLog(fragmentShader, 512, nullptr, info);
        std::cerr << "Fragment shader error: " << info << '\n';
    }

    GLuint program = glCreateProgram();
    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);
    glLinkProgram(program);

    glGetProgramiv(program, GL_LINK_STATUS, &success);
    if (!success)
    {
        char info[512];
        glGetProgramInfoLog(program, 512, nullptr, info);
        std::cerr << "Shader linking error: " << info << '\n';
    }

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    return program;
}

void drawShape(const std::vector<float>& vertices,
               float r, float g, float b)
{
    glUseProgram(shaderProgram);

    GLint colorLocation =
        glGetUniformLocation(shaderProgram, "objectColor");

    glUniform4f(colorLocation, r, g, b, 1.0f);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    glBufferData(GL_ARRAY_BUFFER,
                 vertices.size() * sizeof(float),
                 vertices.data(),
                 GL_DYNAMIC_DRAW);

    glDrawArrays(GL_TRIANGLES, 0,
                 static_cast<GLsizei>(vertices.size() / 2));

    glBindVertexArray(0);
}

void drawRectangle(float x, float y,
                   float width, float height,
                   float r, float g, float b)
{
    std::vector<float> vertices = {
        x, y,
        x + width, y,
        x + width, y + height,

        x, y,
        x + width, y + height,
        x, y + height
    };

    drawShape(vertices, r, g, b);
}

void drawCircle(float x, float y, float radius,
                float r, float g, float b)
{
    std::vector<float> vertices;
    const int segments = 40;

    for (int i = 0; i < segments; i++)
    {
        float angle1 = 2.0f * 3.14159265f * i / segments;
        float angle2 = 2.0f * 3.14159265f * (i + 1) / segments;

        vertices.push_back(x);
        vertices.push_back(y);

        vertices.push_back(x + radius * cos(angle1));
        vertices.push_back(y + radius * sin(angle1));

        vertices.push_back(x + radius * cos(angle2));
        vertices.push_back(y + radius * sin(angle2));
    }

    drawShape(vertices, r, g, b);
}

void createBricks()
{
    bricks.clear();

    const int rows = 5;
    const int columns = 10;

    float brickWidth = 0.17f;
    float brickHeight = 0.065f;
    float gap = 0.015f;

    float totalWidth =
        columns * brickWidth + (columns - 1) * gap;

    float startX = -totalWidth / 2.0f;
    float startY = 0.68f;

    float colors[5][3] = {
        {1.0f, 0.2f, 0.3f},
        {1.0f, 0.5f, 0.1f},
        {1.0f, 0.85f, 0.2f},
        {0.2f, 0.9f, 0.5f},
        {0.2f, 0.65f, 1.0f}
    };

    for (int row = 0; row < rows; row++)
    {
        for (int col = 0; col < columns; col++)
        {
            Brick brick;

            brick.x = startX + col * (brickWidth + gap);
            brick.y = startY - row * (brickHeight + gap);
            brick.width = brickWidth;
            brick.height = brickHeight;
            brick.active = true;

            brick.r = colors[row][0];
            brick.g = colors[row][1];
            brick.b = colors[row][2];

            bricks.push_back(brick);
        }
    }
}

void resetGame()
{
    paddleX = 0.0f;

    ballX = 0.0f;
    ballY = -0.65f;

    ballSpeedX = 0.45f;
    ballSpeedY = 0.55f;

    score = 0;
    lives = 3;

    gameOver = false;
    won = false;

    createBricks();
}

void updateWindowTitle(GLFWwindow* window)
{
    std::ostringstream title;

    title << "Brick Breaker | ID: 0432410005101036"
          << " | Score: " << score
          << " | Lives: " << lives;

    if (gameOver)
        title << " | GAME OVER - Press R to Restart";

    if (won)
        title << " | YOU WIN! - Press R to Restart";

    glfwSetWindowTitle(window, title.str().c_str());
}

void processInput(GLFWwindow* window, float deltaTime)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
        resetGame();

    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        paddleX -= 1.1f * deltaTime;

    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        paddleX += 1.1f * deltaTime;

    paddleX = clampValue(
        paddleX,
        -1.0f + paddleWidth / 2.0f,
         1.0f - paddleWidth / 2.0f
    );
}

void updateGame(float deltaTime)
{
    if (gameOver || won)
        return;

    ballX += ballSpeedX * deltaTime;
    ballY += ballSpeedY * deltaTime;

    // Left and right walls
    if (ballX - ballRadius < -1.0f)
    {
        ballX = -1.0f + ballRadius;
        ballSpeedX = std::abs(ballSpeedX);
    }

    if (ballX + ballRadius > 1.0f)
    {
        ballX = 1.0f - ballRadius;
        ballSpeedX = -std::abs(ballSpeedX);
    }

    // Top wall
    if (ballY + ballRadius > 1.0f)
    {
        ballY = 1.0f - ballRadius;
        ballSpeedY = -std::abs(ballSpeedY);
    }

    // Paddle collision
    float paddleY = -0.85f;
    float paddleLeft = paddleX - paddleWidth / 2.0f;
    float paddleRight = paddleX + paddleWidth / 2.0f;

    if (ballSpeedY < 0 &&
        ballY - ballRadius <= paddleY + paddleHeight &&
        ballY + ballRadius >= paddleY &&
        ballX + ballRadius >= paddleLeft &&
        ballX - ballRadius <= paddleRight)
    {
        ballY = paddleY + paddleHeight + ballRadius;
        ballSpeedY = std::abs(ballSpeedY);

        // Change bounce direction depending on impact position
        float hitPosition =
            (ballX - paddleX) / (paddleWidth / 2.0f);

        ballSpeedX = hitPosition * 0.75f;
    }

    // Brick collision
    for (Brick& brick : bricks)
    {
        if (!brick.active)
            continue;

        bool overlapX =
            ballX + ballRadius >= brick.x &&
            ballX - ballRadius <= brick.x + brick.width;

        bool overlapY =
            ballY + ballRadius >= brick.y &&
            ballY - ballRadius <= brick.y + brick.height;

        if (overlapX && overlapY)
        {
            brick.active = false;
            score += 10;

            // Bounce away from the brick
            ballSpeedY = -ballSpeedY;
            break;
        }
    }

    // Lose a life when the ball falls below the paddle
    if (ballY + ballRadius < -1.0f)
    {
        lives--;

        if (lives <= 0)
        {
            gameOver = true;
        }
        else
        {
            ballX = 0.0f;
            ballY = -0.65f;

            ballSpeedX = 0.45f;
            ballSpeedY = 0.55f;
        }
    }

    // Win when every brick is destroyed
    bool remainingBricks = false;

    for (const Brick& brick : bricks)
    {
        if (brick.active)
        {
            remainingBricks = true;
            break;
        }
    }

    if (!remainingBricks)
        won = true;
}

void renderGame()
{
    // Black background
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw paddle
    drawRectangle(
        paddleX - paddleWidth / 2.0f,
        -0.85f,
        paddleWidth,
        paddleHeight,
        0.0f, 0.9f, 1.0f
    );

    // Draw ball
    drawCircle(
        ballX, ballY, ballRadius,
        1.0f, 1.0f, 1.0f
    );

    // Draw active bricks
    for (const Brick& brick : bricks)
    {
        if (brick.active)
        {
            drawRectangle(
                brick.x, brick.y,
                brick.width, brick.height,
                brick.r, brick.g, brick.b
            );
        }
    }

    // Game-over indicator
    if (gameOver)
    {
        drawRectangle(
            -0.35f, -0.10f,
             0.70f,  0.08f,
            1.0f, 0.0f, 0.0f
        );
    }

    // Win indicator
    if (won)
    {
        drawRectangle(
            -0.35f, -0.10f,
             0.70f,  0.08f,
            0.0f, 1.0f, 0.3f
        );
    }
}

int main()
{
    if (!glfwInit())
    {
        std::cout << "Failed to initialize GLFW\n";
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(
        WIDTH, HEIGHT,
        "Brick Breaker | ID: 0432410005101036",
        nullptr, nullptr
    );

    if (!window)
    {
        std::cout << "Failed to create window\n";
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    if (!gladLoadGLLoader(
            (GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD\n";
        glfwTerminate();
        return -1;
    }

    glViewport(0, 0, WIDTH, HEIGHT);

    shaderProgram = createShaderProgram();

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    glVertexAttribPointer(
        0, 2, GL_FLOAT, GL_FALSE,
        2 * sizeof(float), (void*)0
    );

    glEnableVertexAttribArray(0);

    resetGame();

    float lastFrame = 0.0f;

    while (!glfwWindowShouldClose(window))
    {
        float currentFrame =
            static_cast<float>(glfwGetTime());

        float deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        if (deltaTime > 0.05f)
            deltaTime = 0.05f;

        processInput(window, deltaTime);
        updateGame(deltaTime);
        renderGame();
        updateWindowTitle(window);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteBuffers(1, &VBO);
    glDeleteVertexArrays(1, &VAO);
    glDeleteProgram(shaderProgram);

    glfwTerminate();

    return 0;
}
