# BrickBreaker

## Folder layout
```
BrickBreaker/
├── Makefile
├── src/       main.cpp, glad.c
├── include/   GLFW, glad, KHR headers
├── lib/       glfw3.dll (Windows)
└── build/     created by make (exe goes here)
```

## Windows
1. Install MSYS2 (https://www.msys2.org) and in its terminal run:
   `pacman -S make mingw-w64-ucrt-x86_64-gcc`
2. Add `C:\msys64\ucrt64\bin` and `C:\msys64\usr\bin` to your PATH.
3. Open the BrickBreaker folder in VS Code.
4. In the VS Code terminal run `make` (or press Ctrl+Shift+B).

## Linux
`sudo apt install build-essential libglfw3-dev`, then run `make`.

`make clean` removes the build folder.
