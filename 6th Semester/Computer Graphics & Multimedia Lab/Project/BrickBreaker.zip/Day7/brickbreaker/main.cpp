// ======================================================================
//  BRICK BREAKER  -  a small OpenGL 3.3 game
//
//  Controls
//      LEFT / RIGHT  (or A / D)   move the paddle
//      SPACE                      launch the ball
//      R                          restart
//      ESC                        quit
//
//  Score and lives are shown in the window title.
//
//  How it works (the whole game in 5 ideas):
//    1. Everything on screen is a rectangle. We draw ONE unit square
//       (0..1) and use a matrix to move/scale it to any position/size.
//       (Same trick as the translate/scale lessons.)
//    2. An orthographic projection lets us think in pixels (800x600)
//       instead of OpenGL's -1..1 coordinates.
//    3. The ball is drawn as a rectangle too, but the fragment shader
//       throws away the corners, which leaves a circle.
//    4. The game logic runs in fixed 1/120 s steps, so it behaves the
//       same on slow and fast computers.
//    5. Collisions: circle-vs-rectangle for the paddle and the bricks.
// ======================================================================
#include "glad.h"
#include "glfw3.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader_utils.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

// ----------------------------------------------------------------------
//  Settings - change these numbers to tweak the game
// ----------------------------------------------------------------------
const int   SCREEN_W = 800;
const int   SCREEN_H = 600;

const float PADDLE_W     = 110.0f;
const float PADDLE_H     = 16.0f;
const float PADDLE_Y     = SCREEN_H - 40.0f;   // top edge of the paddle
const float PADDLE_SPEED = 600.0f;             // pixels per second

const float BALL_RADIUS      = 8.0f;
const float BALL_START_SPEED = 380.0f;         // pixels per second
const float BALL_MAX_SPEED   = 650.0f;         // ball speeds up as bricks break

const int   BRICK_COLS = 10;
const int   BRICK_ROWS = 6;
const float BRICK_W    = static_cast<float>(SCREEN_W) / BRICK_COLS;
const float BRICK_H    = 24.0f;
const float BRICK_TOP  = 60.0f;                // y of the first row
const float BRICK_GAP  = 2.0f;                 // empty border around each brick

const int   START_LIVES = 3;
const float TIME_STEP   = 1.0f / 120.0f;       // physics step (seconds)

// ----------------------------------------------------------------------
//  Shaders
//  The vertex shader places the unit square on screen.
//  The fragment shader colors it (and cuts it into a circle if asked).
// ----------------------------------------------------------------------
const char* vertexShaderSource = R"(#version 330 core
layout (location = 0) in vec2 aPos;   // corner of the unit square (0..1)

uniform mat4 projection;              // pixels -> OpenGL coordinates
uniform mat4 model;                   // unit square -> position and size

out vec2 uv;                          // 0..1 across the square

void main()
{
    uv = aPos;
    gl_Position = projection * model * vec4(aPos, 0.0, 1.0);
}
)";

const char* fragmentShaderSource = R"(#version 330 core
in vec2 uv;
out vec4 FragColor;

uniform vec3 color;
uniform bool circle;                  // true -> draw a circle instead of a rectangle

void main()
{
    if (circle && length(uv - vec2(0.5)) > 0.5)
        discard;                      // outside the circle: draw nothing
    FragColor = vec4(color, 1.0);
}
)";

// ----------------------------------------------------------------------
//  Game data
// ----------------------------------------------------------------------
enum class State { Playing, Won, Lost };

struct Brick
{
    float     x, y;        // top-left corner
    glm::vec3 color;
    bool      alive;
};

struct Game
{
    State  state;
    int    score;
    int    lives;

    float  paddleX;        // left edge of the paddle

    glm::vec2 ballPos;     // CENTER of the ball
    glm::vec2 ballVel;     // pixels per second
    float     ballSpeed;
    bool      ballStuck;   // true while the ball rides on the paddle

    std::vector<Brick> bricks;
    int    bricksLeft;
};

// Drawing objects (filled in by initRenderer)
unsigned int shaderProgram, quadVAO;
int locModel, locColor, locCircle;

// ----------------------------------------------------------------------
//  Rendering helpers
// ----------------------------------------------------------------------

// Create the shader program and the one unit square we reuse for everything.
void initRenderer()
{
    shaderProgram = createShaderProgram(vertexShaderSource, fragmentShaderSource);
    glUseProgram(shaderProgram);

    // Orthographic projection: x goes 0..800 (left->right),
    // y goes 0..600 (TOP->BOTTOM, like on a normal screen).
    glm::mat4 projection = glm::ortho(0.0f, static_cast<float>(SCREEN_W),
                                      static_cast<float>(SCREEN_H), 0.0f,
                                      -1.0f, 1.0f);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"),
                       1, GL_FALSE, glm::value_ptr(projection));

    locModel  = glGetUniformLocation(shaderProgram, "model");
    locColor  = glGetUniformLocation(shaderProgram, "color");
    locCircle = glGetUniformLocation(shaderProgram, "circle");

    // A unit square made of two triangles (6 vertices, x and y only).
    float quad[] = {
        0.0f, 0.0f,   1.0f, 0.0f,   1.0f, 1.0f,
        0.0f, 0.0f,   1.0f, 1.0f,   0.0f, 1.0f
    };

    unsigned int VBO;
    glGenVertexArrays(1, &quadVAO);
    glGenBuffers(1, &VBO);
    glBindVertexArray(quadVAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
}

// Draw a filled rectangle (or circle) at pixel position x,y with size w,h.
void drawRect(float x, float y, float w, float h, glm::vec3 color, bool circle = false)
{
    // model = move to (x,y) * stretch to (w,h)
    glm::mat4 model = glm::translate(glm::mat4(1.0f), glm::vec3(x, y, 0.0f));
    model = glm::scale(model, glm::vec3(w, h, 1.0f));

    glUniformMatrix4fv(locModel, 1, GL_FALSE, glm::value_ptr(model));
    glUniform3f(locColor, color.r, color.g, color.b);
    glUniform1i(locCircle, circle ? 1 : 0);
    glDrawArrays(GL_TRIANGLES, 0, 6);
}

// Draw one complete frame.
void render(const Game& g)
{
    // Background changes color when the game ends.
    if (g.state == State::Won)       glClearColor(0.05f, 0.20f, 0.10f, 1.0f);  // green
    else if (g.state == State::Lost) glClearColor(0.22f, 0.05f, 0.05f, 1.0f);  // red
    else                             glClearColor(0.07f, 0.07f, 0.12f, 1.0f);  // dark blue
    glClear(GL_COLOR_BUFFER_BIT);

    glUseProgram(shaderProgram);
    glBindVertexArray(quadVAO);

    // Bricks (leave a small gap so they look separate)
    for (const Brick& b : g.bricks)
        if (b.alive)
            drawRect(b.x + BRICK_GAP, b.y + BRICK_GAP,
                     BRICK_W - 2 * BRICK_GAP, BRICK_H - 2 * BRICK_GAP, b.color);

    // Paddle
    drawRect(g.paddleX, PADDLE_Y, PADDLE_W, PADDLE_H, glm::vec3(0.85f, 0.85f, 0.95f));

    // Ball (a rectangle cut into a circle by the fragment shader)
    drawRect(g.ballPos.x - BALL_RADIUS, g.ballPos.y - BALL_RADIUS,
             BALL_RADIUS * 2, BALL_RADIUS * 2, glm::vec3(1.0f, 0.9f, 0.3f), true);

    // Lives: one small dot per life, top-left corner
    for (int i = 0; i < g.lives; i++)
        drawRect(14.0f + i * 22.0f, 16.0f, 14.0f, 14.0f, glm::vec3(0.95f, 0.3f, 0.35f), true);
}

// ----------------------------------------------------------------------
//  Game logic
// ----------------------------------------------------------------------

// Put the ball back on the paddle, waiting for SPACE.
void resetBall(Game& g)
{
    g.ballStuck = true;
    g.ballSpeed = BALL_START_SPEED;
    g.ballVel   = glm::vec2(0.0f);
    g.ballPos   = glm::vec2(g.paddleX + PADDLE_W / 2.0f, PADDLE_Y - BALL_RADIUS);
}

// Start (or restart) a whole game.
void newGame(Game& g)
{
    g.state     = State::Playing;
    g.score     = 0;
    g.lives     = START_LIVES;
    g.paddleX   = (SCREEN_W - PADDLE_W) / 2.0f;

    // One color per row, from red (top) to purple (bottom).
    const glm::vec3 rowColors[BRICK_ROWS] = {
        {0.90f, 0.25f, 0.25f}, {0.95f, 0.55f, 0.20f}, {0.95f, 0.85f, 0.25f},
        {0.35f, 0.80f, 0.40f}, {0.30f, 0.65f, 0.95f}, {0.60f, 0.45f, 0.95f}
    };

    g.bricks.clear();
    for (int row = 0; row < BRICK_ROWS; row++)
        for (int col = 0; col < BRICK_COLS; col++)
            g.bricks.push_back({ col * BRICK_W, BRICK_TOP + row * BRICK_H, rowColors[row], true });
    g.bricksLeft = static_cast<int>(g.bricks.size());

    resetBall(g);
}

// Circle-vs-rectangle test.
// Returns true if the circle touches the rectangle and gives back the
// vector from the closest point on the rectangle to the circle center.
bool circleHitsRect(glm::vec2 center, float radius,
                    float rx, float ry, float rw, float rh,
                    glm::vec2& diff)
{
    // Closest point on the rectangle to the circle's center
    glm::vec2 closest(std::clamp(center.x, rx, rx + rw),
                      std::clamp(center.y, ry, ry + rh));
    diff = center - closest;
    return glm::dot(diff, diff) < radius * radius;
}

// Move the whole simulation forward by dt seconds.
void update(Game& g, GLFWwindow* window, float dt)
{
    if (g.state != State::Playing)
        return;

    // ---- paddle input ----
    float move = 0.0f;
    if (glfwGetKey(window, GLFW_KEY_LEFT)  == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) move -= 1.0f;
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) move += 1.0f;
    g.paddleX += move * PADDLE_SPEED * dt;
    g.paddleX  = std::clamp(g.paddleX, 0.0f, SCREEN_W - PADDLE_W);   // stay on screen

    // ---- ball waiting on the paddle ----
    if (g.ballStuck)
    {
        g.ballPos.x = g.paddleX + PADDLE_W / 2.0f;                   // ride along
        if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
        {
            g.ballStuck = false;
            g.ballVel   = glm::normalize(glm::vec2(0.35f, -1.0f)) * g.ballSpeed;  // up and a bit right
        }
        return;
    }

    // ---- move the ball ----
    g.ballPos += g.ballVel * dt;

    // ---- walls (left, right, top) ----
    if (g.ballPos.x - BALL_RADIUS < 0.0f)
    {
        g.ballPos.x = BALL_RADIUS;
        g.ballVel.x = std::abs(g.ballVel.x);            // force it to go right
    }
    if (g.ballPos.x + BALL_RADIUS > SCREEN_W)
    {
        g.ballPos.x = SCREEN_W - BALL_RADIUS;
        g.ballVel.x = -std::abs(g.ballVel.x);           // force it to go left
    }
    if (g.ballPos.y - BALL_RADIUS < 0.0f)
    {
        g.ballPos.y = BALL_RADIUS;
        g.ballVel.y = std::abs(g.ballVel.y);            // force it to go down
    }

    // ---- ball fell below the paddle: lose a life ----
    if (g.ballPos.y - BALL_RADIUS > SCREEN_H)
    {
        g.lives--;
        if (g.lives <= 0) g.state = State::Lost;
        else              resetBall(g);
        return;
    }

    // ---- paddle ----
    glm::vec2 diff;
    if (g.ballVel.y > 0.0f &&
        circleHitsRect(g.ballPos, BALL_RADIUS, g.paddleX, PADDLE_Y, PADDLE_W, PADDLE_H, diff))
    {
        // Where did we hit? -1 = left edge, 0 = middle, +1 = right edge.
        float hit = (g.ballPos.x - (g.paddleX + PADDLE_W / 2.0f)) / (PADDLE_W / 2.0f);
        hit = std::clamp(hit, -1.0f, 1.0f);

        // Hitting the edge sends the ball out at up to 60 degrees.
        float angle = hit * glm::radians(60.0f);
        g.ballVel = glm::vec2(std::sin(angle), -std::cos(angle)) * g.ballSpeed;
        g.ballPos.y = PADDLE_Y - BALL_RADIUS;           // sit on top, don't stick inside
    }

    // ---- bricks (handle at most one per step) ----
    for (Brick& b : g.bricks)
    {
        if (!b.alive) continue;

        float bx = b.x + BRICK_GAP,         by = b.y + BRICK_GAP;
        float bw = BRICK_W - 2 * BRICK_GAP, bh = BRICK_H - 2 * BRICK_GAP;

        if (!circleHitsRect(g.ballPos, BALL_RADIUS, bx, by, bw, bh, diff))
            continue;

        // Push the ball out of the brick...
        float dist = glm::length(diff);
        if (dist > 0.0f)
            g.ballPos += diff / dist * (BALL_RADIUS - dist);

        // ...and bounce. If we hit mostly from the side flip X, otherwise flip Y.
        if (std::abs(diff.x) > std::abs(diff.y))
            g.ballVel.x = (diff.x > 0.0f) ? std::abs(g.ballVel.x) : -std::abs(g.ballVel.x);
        else
            g.ballVel.y = (diff.y > 0.0f) ? std::abs(g.ballVel.y) : -std::abs(g.ballVel.y);

        b.alive = false;
        g.bricksLeft--;
        g.score += 10;

        // Speed up a little with every brick.
        g.ballSpeed = std::min(g.ballSpeed + 6.0f, BALL_MAX_SPEED);
        g.ballVel   = glm::normalize(g.ballVel) * g.ballSpeed;

        if (g.bricksLeft == 0)
            g.state = State::Won;
        break;
    }
}

// Show score / lives / hints in the window title (no text rendering needed).
void updateTitle(GLFWwindow* window, const Game& g)
{
    static std::string lastTitle;

    char title[128];
    if (g.state == State::Won)
        std::snprintf(title, sizeof(title), "Brick Breaker - YOU WIN!  Score: %d  (press R to play again)", g.score);
    else if (g.state == State::Lost)
        std::snprintf(title, sizeof(title), "Brick Breaker - GAME OVER  Score: %d  (press R to try again)", g.score);
    else if (g.ballStuck)
        std::snprintf(title, sizeof(title), "Brick Breaker - Score: %d  Lives: %d  -  press SPACE to launch", g.score, g.lives);
    else
        std::snprintf(title, sizeof(title), "Brick Breaker - Score: %d  Lives: %d", g.score, g.lives);

    if (lastTitle != title)                 // only touch the window when the text changes
    {
        glfwSetWindowTitle(window, title);
        lastTitle = title;
    }
}

// ----------------------------------------------------------------------
//  main
// ----------------------------------------------------------------------
int main()
{
    // --- window ---
    if (!glfwInit())
    {
        std::cout << "Failed to initialize GLFW" << std::endl;
        return -1;
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);          // fixed size keeps things simple
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    GLFWwindow* window = glfwCreateWindow(SCREEN_W, SCREEN_H, "Brick Breaker", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);                                  // vsync: match the monitor's refresh rate

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    int fbWidth, fbHeight;
    glfwGetFramebufferSize(window, &fbWidth, &fbHeight);
    glViewport(0, 0, fbWidth, fbHeight);

    // --- game setup ---
    initRenderer();
    Game game;
    newGame(game);

    // --- main loop ---
    double previousTime = glfwGetTime();
    double accumulator  = 0.0;     // time we still "owe" the physics

    while (!glfwWindowShouldClose(window))
    {
        double now = glfwGetTime();
        accumulator += std::min(now - previousTime, 0.25);   // cap: avoids a huge jump after a freeze
        previousTime = now;

        glfwPollEvents();
        if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
            glfwSetWindowShouldClose(window, true);
        if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
            newGame(game);

        // Run the game in small fixed steps until we have caught up with real time.
        while (accumulator >= TIME_STEP)
        {
            update(game, window, TIME_STEP);
            accumulator -= TIME_STEP;
        }

        render(game);
        updateTitle(window, game);
        glfwSwapBuffers(window);
    }

    glfwTerminate();
    return 0;
}
