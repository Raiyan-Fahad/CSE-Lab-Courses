// ======================================================================
//  LESSON: Uniform color - hold a key (TEMPORARY change)
//
//  A UNIFORM is a global variable inside a shader that our C++ code
//  (the CPU) can change at any time:
//    - it is global: one value per shader program, visible to every stage
//    - it keeps its value until we set it again
//  Here the fragment shader's color comes from a uniform called "ourColor".
//
//  The triangle slowly pulses green.
//  HOLD  R  -> it turns red.   RELEASE R -> it goes back to green.
//
//  Press ESC to close the window.
//  Run it with:   make run APP=lessons/uniform_color_hold
// ======================================================================
#include "glad.h"    // loads the OpenGL functions
#include "glfw3.h"   // creates the window and reads the keyboard

#include "shader_utils.h"   // createShaderProgram(): compiles + links the shaders

#include <cmath>
#include <iostream>

// Window size
const unsigned int SCR_WIDTH  = 800;
const unsigned int SCR_HEIGHT = 600;

// ----------------------------------------------------------------------
//  Shaders (small GPU programs, written in GLSL)
// ----------------------------------------------------------------------
const char* vertexShaderSource = R"(#version 330 core
layout (location = 0) in vec3 aPos;

void main()
{
    gl_Position = vec4(aPos, 1.0);        // just pass the position through
}
)";

const char* fragmentShaderSource = R"(#version 330 core
out vec4 FragColor;

uniform vec4 ourColor;                    // set from C++ code, see the render loop

void main()
{
    FragColor = ourColor;
}
)";

void framebuffer_size_callback(GLFWwindow* /*window*/, int width, int height);
void processInput(GLFWwindow* window);

int main()
{
    // ---- 1. Create the window ---------------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);                // we want OpenGL 3.3
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Uniform color (hold R)", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // ---- 2. Load the OpenGL functions (GLAD) -------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // ---- 3. Build the shader program ---------------------------------
    unsigned int shaderProgram = createShaderProgram(vertexShaderSource, fragmentShaderSource);

    // ---- 4. Send the shape to the GPU --------------------------------
    float vertices[] = {
         0.5f, -0.5f, 0.0f,   // bottom right
        -0.5f, -0.5f, 0.0f,   // bottom left
         0.0f,  0.5f, 0.0f    // top
    };

    unsigned int VBO, VAO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);                                       // VAO remembers the setup below
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // Attribute 0 = position: 3 floats (x, y, z) per vertex
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // ---- 5. Render loop (runs once per frame) ------------------------
    while (!glfwWindowShouldClose(window))
    {
        processInput(window);

        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);                     // background color
        glClear(GL_COLOR_BUFFER_BIT);

        glUseProgram(shaderProgram);                              // must be active before setting uniforms

        // Pulse the green value: sin() swings between -1 and 1,
        // so  sin/2 + 0.5  swings between 0 and 1.
        float timeValue  = static_cast<float>(glfwGetTime());
        float greenValue = std::sin(timeValue) / 2.0f + 0.5f;

        // Find the "ourColor" uniform in the shader, then write a color (r, g, b, a) into it.
        int colorLocation = glGetUniformLocation(shaderProgram, "ourColor");
        glUniform4f(colorLocation, 0.0f, greenValue, 0.0f, 1.0f);

        // TEMPORARY: red only while R is held. On the next frame the green
        // color above is written again, so releasing R brings the green back.
        if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
            glUniform4f(colorLocation, 1.0f, 0.0f, 0.0f, 1.0f);

        glBindVertexArray(VAO);
        glDrawArrays(GL_TRIANGLES, 0, 3);

        glfwSwapBuffers(window);                                  // show the finished frame
        glfwPollEvents();                                         // handle keyboard / window events
    }

    // ---- 6. Clean up --------------------------------------------------
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteProgram(shaderProgram);

    glfwTerminate();
    return 0;
}

// Close the window when ESC is pressed.
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

// Keep the OpenGL viewport the same size as the window when it is resized.
void framebuffer_size_callback(GLFWwindow* /*window*/, int width, int height)
{
    glViewport(0, 0, width, height);
}
