// ======================================================================
//  LESSON: Rotate (spin) a rectangle
//
//  Every frame we build a rotation matrix, send it to the vertex shader as
//  a uniform, and the GPU rotates every vertex with it.
//
//  Here: the yellow rectangle spins around its center.
//
//  Note: the window is 800x600 but OpenGL's screen is a -1..1 square, so
//  the picture is stretched and the "square" looks skewed while it spins.
//  The Brick Breaker game fixes this with an orthographic projection.
//
//  Press ESC to close the window.
//  Run it with:   make run APP=lessons/rotate
// ======================================================================
#include "glad.h"    // loads the OpenGL functions
#include "glfw3.h"   // creates the window and reads the keyboard

#include <glm/glm.hpp>                    // vec3, mat4, ...
#include <glm/gtc/matrix_transform.hpp>   // translate, scale, rotate
#include <glm/gtc/type_ptr.hpp>           // value_ptr: matrix -> pointer for OpenGL

#include "shader_utils.h"   // createShaderProgram(): compiles + links the shaders

#include <cmath>
#include <iostream>

// Window size
const unsigned int SCR_WIDTH  = 800;
const unsigned int SCR_HEIGHT = 600;

// ----------------------------------------------------------------------
//  Shaders (small GPU programs, written in GLSL)
// ----------------------------------------------------------------------
const char* vertexShaderSource = R"(#version 330 core
layout (location = 0) in vec3 aPos;

uniform mat4 transform;                   // set from C++ code, see the render loop

void main()
{
    gl_Position = transform * vec4(aPos, 1.0);   // move/scale/rotate every vertex
}
)";

const char* fragmentShaderSource = R"(#version 330 core
out vec4 FragColor;

void main()
{
    FragColor = vec4(1.0, 1.0, 0.0, 1.0);        // solid yellow
}
)";

void framebuffer_size_callback(GLFWwindow* /*window*/, int width, int height);
void processInput(GLFWwindow* window);

int main()
{
    // ---- 1. Create the window ---------------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);                // we want OpenGL 3.3
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Rotating Yellow Rectangle", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // ---- 2. Load the OpenGL functions (GLAD) -------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // ---- 3. Build the shader program ---------------------------------
    unsigned int shaderProgram = createShaderProgram(vertexShaderSource, fragmentShaderSource);

    // ---- 4. Send the shape to the GPU --------------------------------
    // A rectangle is made of 2 triangles = 6 vertices.
    float vertices[] = {
        // first triangle
         0.5f,  0.5f, 0.0f,   // top right
         0.5f, -0.5f, 0.0f,   // bottom right
        -0.5f, -0.5f, 0.0f,   // bottom left
        // second triangle
         0.5f,  0.5f, 0.0f,   // top right
        -0.5f, -0.5f, 0.0f,   // bottom left
        -0.5f,  0.5f, 0.0f    // top left
    };

    unsigned int VBO, VAO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);                                       // VAO remembers the setup below
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // Attribute 0 = position: 3 floats (x, y, z) per vertex
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // ---- 5. Render loop (runs once per frame) ------------------------
    while (!glfwWindowShouldClose(window))
    {
        processInput(window);

        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);                     // background color
        glClear(GL_COLOR_BUFFER_BIT);

        glUseProgram(shaderProgram);                              // must be active before setting uniforms

        glm::mat4 transform = glm::mat4(1.0f);       // 4x4 identity matrix to start from

        // rotate( matrix, angle in radians, axis )
        //   angle = time in seconds -> about 57 degrees per second
        //   axis (0,0,1) = the Z axis, which points out of the screen,
        //   so in 2D the rectangle simply spins in place.
        transform = glm::rotate(transform, static_cast<float>(glfwGetTime()), glm::vec3(0.0f, 0.0f, 1.0f));

        // Send the matrix to the "transform" uniform in the vertex shader
        unsigned int transformLoc = glGetUniformLocation(shaderProgram, "transform");
        glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transform));  // 1 matrix, no transpose

        glBindVertexArray(VAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);

        glfwSwapBuffers(window);                                  // show the finished frame
        glfwPollEvents();                                         // handle keyboard / window events
    }

    // ---- 6. Clean up --------------------------------------------------
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteProgram(shaderProgram);

    glfwTerminate();
    return 0;
}

// Close the window when ESC is pressed.
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

// Keep the OpenGL viewport the same size as the window when it is resized.
void framebuffer_size_callback(GLFWwindow* /*window*/, int width, int height)
{
    glViewport(0, 0, width, height);
}
