// ======================================================================
//  shader_utils.h  -  tiny helper to turn shader source text into a
//                     ready-to-use OpenGL shader program.
//
//  Every program in this folder used to repeat these ~40 lines.
//  Usage:
//      unsigned int program = createShaderProgram(vertexSrc, fragmentSrc);
//      glUseProgram(program);
// ======================================================================
#ifndef SHADER_UTILS_H
#define SHADER_UTILS_H

#include "glad.h"
#include <iostream>

// Compile ONE shader stage (GL_VERTEX_SHADER or GL_FRAGMENT_SHADER).
// Prints the compiler's error message if the GLSL code is wrong.
inline unsigned int compileShader(unsigned int type, const char* source)
{
    unsigned int shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, NULL);
    glCompileShader(shader);

    int success;
    char infoLog[512];
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::"
                  << (type == GL_VERTEX_SHADER ? "VERTEX" : "FRAGMENT")
                  << "::COMPILATION_FAILED\n" << infoLog << std::endl;
    }
    return shader;
}

// Compile both stages and link them into one shader program.
inline unsigned int createShaderProgram(const char* vertexSource, const char* fragmentSource)
{
    unsigned int vertexShader   = compileShader(GL_VERTEX_SHADER,   vertexSource);
    unsigned int fragmentShader = compileShader(GL_FRAGMENT_SHADER, fragmentSource);

    unsigned int program = glCreateProgram();
    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);
    glLinkProgram(program);

    int success;
    char infoLog[512];
    glGetProgramiv(program, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(program, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
    }

    // The individual shaders are copied into the program, so we can free them.
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
    return program;
}

#endif // SHADER_UTILS_H
