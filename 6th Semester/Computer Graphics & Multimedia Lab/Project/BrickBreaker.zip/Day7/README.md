# Day 7 – OpenGL: Uniforms, Transformations and Brick Breaker

One project, one Makefile, one shared copy of GLFW / GLAD / GLM.

## Quick start

Open this folder in VS Code, then either:

* press **Ctrl+Shift+B** (runs the *Run Brick Breaker* task), or
* open a terminal and type:

```
make
```

To run any other program, give the folder that contains its `main.cpp`:

```
make run APP=lessons/scale
```

Or open any `main.cpp` in VS Code and use **Terminal → Run Task → Run program in current file's folder**.

| Command | What it does |
|---|---|
| `make` | build + run Brick Breaker |
| `make run APP=<folder>` | build + run another program |
| `make build` | build only |
| `make clean` | delete the `build` folder |
| `make win` / `make linux` | force a platform (normally auto-detected) |

## Brick Breaker

| Key | Action |
|---|---|
| ← → or A D | move the paddle |
| Space | launch the ball |
| R | restart |
| Esc | quit |

Score and lives are shown in the window title. Clear all 60 bricks to win.
The game settings (paddle size, ball speed, brick rows…) are the constants at the top of
`brickbreaker/main.cpp`.

## Folder layout

```
Day7/
├── Makefile                  builds and runs everything
├── brickbreaker/main.cpp     the game
├── lessons/                  the exercises from class
│   ├── uniform_color_hold/   press and HOLD R  -> red, release -> green
│   ├── uniform_color_latch/  press R once       -> red forever
│   ├── translate/            rectangle slides left/right
│   ├── scale/                rectangle grows/shrinks
│   └── rotate/               rectangle spins
├── include/                  headers shared by all programs
│   ├── glad.h, glfw3.h, KHR/ OpenGL loader + window library
│   ├── glm/                  math library (vectors, matrices)
│   ├── shader_utils.h        compiles/links shaders (used by every program)
│   └── shader_m.h, shader_s.h, stb_image.h   for later lessons (shaders from files, textures)
├── src/glad.c                OpenGL loader source
├── lib/glfw3.dll             GLFW for Windows
├── resources/                images for later lessons (textures)
├── build/                    compiled programs appear here
└── .vscode/                  VS Code tasks + IntelliSense settings
```

## Setup

### Windows
1. Install **MSYS2** from <https://www.msys2.org/>.
2. In the MSYS2 terminal run: `pacman -S base-devel gcc`
3. Add `C:\msys64\usr\bin` to your `PATH` (so `make` and `g++` work in any terminal), then restart VS Code.
4. Run `make`.

`lib/glfw3.dll` is already included; the Makefile copies it next to the `.exe` for you.
If the window fails to open, check your OpenGL version (this project needs 3.3 or newer) and update your graphics drivers.

### Linux
```
sudo apt-get install build-essential libglfw3-dev
make
```
