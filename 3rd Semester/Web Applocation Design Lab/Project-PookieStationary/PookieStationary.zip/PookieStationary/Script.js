document.querySelectorAll(".category").forEach((category, index) => {
    category.addEventListener("click", (e) => {
        e.preventDefault();
        const pageNumber = index + 1; // index starts from 0, so +1
        window.open(`pages/CAT_${pageNumber}.html`, '_blank');
    });
});


